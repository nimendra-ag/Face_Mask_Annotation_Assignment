# Face mask detection > 2025-03-16 7:13pm
https://universe.roboflow.com/nimendraproject/face-mask-detection-zlvcv

Provided by a Roboflow user
License: CC BY 4.0

